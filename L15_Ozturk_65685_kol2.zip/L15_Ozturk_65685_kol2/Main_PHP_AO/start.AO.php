<?php
include __DIR__ . '/../Main_Include_AO/header_AO.php';
include __DIR__ . '/../Main_Include_AO/nav_AO.php';
?>

<div style="background-image: url('../Img_AO/background.jpg'); background-size: cover; height: 500px; text-align: center; color: white; display: flex; justify-content: center; align-items: center;">
    
</div>

<?php
include __DIR__ . '/../Main_Include_AO/footer_AO.php';
?>
