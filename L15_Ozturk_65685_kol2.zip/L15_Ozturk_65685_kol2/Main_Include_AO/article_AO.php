<?php
echo '<article style="padding: 20px; text-align: center; max-width: 800px; margin: auto; background-color: #f9f9f9; border-radius: 8px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);">
        <h2>Witaj na stronie urodzinowej!</h2>
        <p>To jest wyjątkowa strona poświęcona Twoim urodzinom! Możesz tutaj dodać gości, pisać wiadomości i oglądać zdjęcia z przyjęcia.</p>
        <p>Wybierz jedną z opcji w menu, aby zacząć!</p>
      </article>';
?>
