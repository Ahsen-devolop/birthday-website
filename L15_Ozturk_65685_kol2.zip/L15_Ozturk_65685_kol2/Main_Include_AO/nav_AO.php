<?php
echo '<nav style="background-color: #333; padding: 10px; text-align: center;">
        <a href="start.AO.php" style="color: white; margin: 0 10px; text-decoration: none;">Strona Główna</a>
        <a href="add_Guess.AO.php" style="color: white; margin: 0 10px; text-decoration: none;">Dodaj Gościa</a>
        <a href="see_Guess.AO.php" style="color: white; margin: 0 10px; text-decoration: none;">Lista Gości</a>
        <a href="add_Message.AO.php" style="color: white; margin: 0 10px; text-decoration: none;">Dodaj Wiadomość</a>
        <a href="see_Message.AO.php" style="color: white; margin: 0 10px; text-decoration: none;">Lista Wiadomości</a>
        <a href="gallery.AO.php" style="color: white; margin: 0 10px; text-decoration: none;">Galeria Zdjęć</a>
      </nav>';
?>
