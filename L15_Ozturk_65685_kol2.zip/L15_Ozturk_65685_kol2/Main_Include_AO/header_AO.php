<?php
echo '<header style="background-color: #4CAF50; color: white; padding: 10px; text-align: center; font-size: 24px;">
         🥳Witamy na stronie urodzinowej Ahsen OZTURK 🥳
      </header>';
?>
