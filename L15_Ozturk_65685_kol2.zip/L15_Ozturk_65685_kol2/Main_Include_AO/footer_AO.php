<?php
echo '<footer style="background-color: #4CAF50; color: white; padding: 10px; text-align: center; font-size: 14px; margin-top: 20px;">
        © 2025 Ahsen OZTURK 65685
      </footer>';
?>
